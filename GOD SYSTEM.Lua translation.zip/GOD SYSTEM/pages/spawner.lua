---- /godmode
-- Creating subpage
local subpage = main_page:new_subpage(T("SPAWNER_PAGE"))

-- Creating groups
local spawn_from_group = subpage:new_group(T("SPAWN_FROM_MODS"), GroupRect.TITLE):set_collapsed(true)
local spawn_by_group = subpage:new_group(T("SPAWN_BY_NAME"), GroupRect.TITLE):set_collapsed(true)
local spawned_group = subpage:new_group(T("SPAWNED_VEHICLES"), GroupRect.BODY):set_collapsed(true)

-- Loading functions
require(fs.get_dir_script()..'GOD SYSTEM\\functions\\spawner_functions.lua')

---- Creating functions
-- Spawn from 'mods' folder group
local spawn_from_folder_list = spawn_from_group:new_table_list(T("SPAWN_FROM_MODS"), mods_folder)
spawn_from_folder_list:set_click_callback(function (item)
    vehicle.spawn(mods_folder[item], function (veh)
        ui.popup(T("MAIN_TITLE"), T("SPAWNED_SUCCESS") .. ": " .. mods_folder[item], Icons.CHECKMARK_SUCCESS, PopupType.BOX)
        table.insert(spawned_handles, mods_folder[item])
    end)
end)

-- Spawn by name group
name_input = spawn_by_group:new_input(T("MODEL_NAME"))
local spawn_button = spawn_by_group:new_button(T("SPAWN_BUTTON"), spawn_function)

-- Spawned vehicles group
local spawned_list = spawned_group:new_table_list(T("SPAWNED_VEHICLES"), spawned_names)
spawned_list:set_click_callback(function (item)
    entity.delete(spawned_handles[item],
        function ()
            ui.popup(T("MAIN_TITLE"), T("DELETE_FAILED"), Icons.CANCEL2, PopupType.BOX)
        end,
        function ()
            ui.popup(T("MAIN_TITLE"), T("DELETE_SUCCESS"), Icons.CHECKMARK_SUCCESS, PopupType.BOX)
        end
    )
    spawned_names[item], spawned_handles[item] = nil, nil
end)

local delete_all_button = spawned_group:new_button(T("DELETE_ALL"), delete_all_function)

-- Popup on load
print(T("SPAWNER_PAGE_LOADED"))
