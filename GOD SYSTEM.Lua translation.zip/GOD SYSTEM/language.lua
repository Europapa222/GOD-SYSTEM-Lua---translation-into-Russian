-- =============================================
-- AUTO-DETECT LANGUAGE
-- =============================================

local function detect_language()

    -- Try GTA native detection
    pcall(function()
        if native and native.call then
            local lang = native.call(0x2BDD44CC, 0)  -- example native GET_CURRENT_LANGUAGE
            if lang == 7 then return "ru" end
            return "en"
        end
    end)

    -- Try Windows locale detection
    pcall(function()
        local f = io.popen("wmic os get locale 2>nul")
        if f then
            local result = f:read("*all") or ""
            f:close()

            if result:find("0419") then return "ru" end
            if result:find("0409") then return "en" end
        end
    end)

    -- Try OS env variables
    local env = os.getenv("LANG") or os.getenv("LANGUAGE") or ""
    env = env:lower()

    if env:find("ru") then return "ru" end

    -- Default
    return "en"
end

-- SET CURRENT LANG AUTOMATICALLY
CurrentLang = detect_language()



-- =============================================
--  LANGUAGE SYSTEM
-- =============================================

Lang = {

    -- ==============================
    -- 🌐 ENGLISH
    -- ==============================
    en = {

        -- ==== SYSTEM ====
        MAIN_TITLE = "GOD SYSTEM",
        LOADED_SUCCESS = "Loaded successfully",
        MADE_BY = "Made by lgn with <3",

        -- ==== OFFICE PAGE ====
        OFFICE_PAGE = "Office",
        WAREHOUSES = "Warehouses",
        OFFICE = "Office",
        BUY_CRATES = "Buy crates",
        SELL_CRATES = "Sell crates",

        WAREHOUSES_LIST = "Warehouses",
        WAREHOUSE_0 = "Warehouse #0",
        WAREHOUSE_1 = "Warehouse #1",
        WAREHOUSE_2 = "Warehouse #2",
        WAREHOUSE_3 = "Warehouse #3",
        WAREHOUSE_4 = "Warehouse #4",

        TP_WAREHOUSE = "TP to warehouse",
        TP_OFFICE = "TP to office",

        CRATES_LOOP = "Crates loop",
        GET_CRATES = "Get crates",
        INSTANT_BUY = "Instant buy",
        INSTANT_BUY_FULL = "Instant buy 111 crates",
        DEL_BUY_CD = "Delete buy cooldown",
        INSTANT_SELL = "Instant sell",
        DEL_SELL_CD = "Delete sell cooldown",

        OFFICE_PAGE_LOADED = "Office page loaded successfully",


        -- ==== BUSINESSES PAGE ====
        BUSINESSES_PAGE = "Businesses",
        BUNKER = "Bunker",
        HANGAR = "Hangar",
        CLUBHOUSE = "Clubhouse",
        ACID_LAB = "Acid lab",

        TP_BUNKER = "TP to bunker",

        GET_SUPPLIES = "Get supplies",
        GET_ALL_SUPPLIES = "Get all supplies",
        GET_SUPPLIES_CASH = "Get supplies for cash",
        GET_SUPPLIES_COKE = "Get supplies for coke",
        GET_SUPPLIES_WEED = "Get supplies for weed",
        GET_SUPPLIES_METH = "Get supplies for meth",
        GET_SUPPLIES_DOCS = "Get supplies for documents",

        BUSINESSES_PAGE_LOADED = "Businesses page loaded successfully",


        -- ==== MISC PAGE ====
        MISC_PAGE = "Misc",
        UNLOCKS = "Unlocks",
        OTHER = "Other",

        UNLOCK_DELETED_VEHICLES = "Unlock deleted vehicles",
        UNLOCK_LS_CARMEET_PODIUM = "Unlock LS Car Meet podium prize",

        TP_TO_GUNVAN = "TP to gunvan",

        MISC_PAGE_LOADED = "Misc page loaded successfully",


        -- ==== SPAWNER PAGE ====
        SPAWNER_PAGE = "Spawner",

        SPAWN_FROM_MODS = "Spawn from 'mods' folder",
        SPAWN_BY_NAME = "Spawn by name",
        SPAWNED_VEHICLES = "Spawned vehicles",

        MODEL_NAME = "Model name",
        SPAWN_BUTTON = "Spawn",

        DELETE_ALL = "Delete all",
        DELETE_FAILED = "Failed to delete",
        DELETE_SUCCESS = "Deleted successfully",

        SPAWNED_SUCCESS = "Spawned successfully",
        SPAWNER_PAGE_LOADED = "Spawner page loaded successfully",


        -- ==== EVENTS ====
        EVENTS_LOADED = "Event list loaded successfully",
    },


    -- ==============================
    -- 🇷🇺 RUSSIAN
    -- ==============================
    ru = {

        -- ==== SYSTEM ====
         MAIN_TITLE = "GOD SYSTEM",
        LOADED_SUCCESS = "Успешно загружено",
        MADE_BY = "Создано lgn с <3",

        -- ==== OFFICE PAGE ====
        OFFICE_PAGE = "Офис",
        WAREHOUSES = "Склады",
        OFFICE = "Офис",
        BUY_CRATES = "Покупка ящиков",
        SELL_CRATES = "Продажа ящиков",

        WAREHOUSES_LIST = "Склады",
        WAREHOUSE_0 = "Склад #0",
        WAREHOUSE_1 = "Склад #1",
        WAREHOUSE_2 = "Склад #2",
        WAREHOUSE_3 = "Склад #3",
        WAREHOUSE_4 = "Склад #4",

        TP_WAREHOUSE = "ТП к складу",
        TP_OFFICE = "ТП в офис",

        CRATES_LOOP = "Цикл ящиков",
        GET_CRATES = "Получить ящики",
        INSTANT_BUY = "Мгновенная покупка",
        INSTANT_BUY_FULL = "Мгновенная покупка 111 ящиков",
        DEL_BUY_CD = "Убрать откат покупки",
        INSTANT_SELL = "Мгновенная продажа",
        DEL_SELL_CD = "Убрать откат продажи",

        OFFICE_PAGE_LOADED = "Страница офиса загружена",


        -- ==== BUSINESSES PAGE ====
        BUSINESSES_PAGE = "Бизнесы",
        BUNKER = "Бункер",
        HANGAR = "Ангар",
        CLUBHOUSE = "Клубхаус",
        ACID_LAB = "Кислотная лаборатория",

        TP_BUNKER = "ТП в бункер",

        GET_SUPPLIES = "Получить припасы",
        GET_ALL_SUPPLIES = "Получить все припасы",
        GET_SUPPLIES_CASH = "Припасы за деньги",
        GET_SUPPLIES_COKE = "Припасы за кокаин",
        GET_SUPPLIES_WEED = "Припасы за траву",
        GET_SUPPLIES_METH = "Припасы за мет",
        GET_SUPPLIES_DOCS = "Припасы за документы",

        BUSINESSES_PAGE_LOADED = "Страница бизнесов загружена",


        -- ==== MISC PAGE ====
        MISC_PAGE = "Разное",
        UNLOCKS = "Разблокировки",
        OTHER = "Другое",

        UNLOCK_DELETED_VEHICLES = "Разблокировать удалённые машины",
        UNLOCK_LS_CARMEET_PODIUM = "Разблокировать приз LS Car Meet",

        TP_TO_GUNVAN = "ТП к фургону GunVan",

        MISC_PAGE_LOADED = "Страница Misc загружена",


        -- ==== SPAWNER PAGE ====
        SPAWNER_PAGE = "Спавнер",

        SPAWN_FROM_MODS = "Спавн из папки 'mods'",
        SPAWN_BY_NAME = "Спавн по названию",
        SPAWNED_VEHICLES = "Заспавненные машины",

        MODEL_NAME = "Название модели",
        SPAWN_BUTTON = "Спавн",

        DELETE_ALL = "Удалить все",
        DELETE_FAILED = "Ошибка удаления",
        DELETE_SUCCESS = "Успешно удалено",

        SPAWNED_SUCCESS = "Успешно заспавнено",
        SPAWNER_PAGE_LOADED = "Страница спавнера загружена",


        -- ==== EVENTS ====
        EVENTS_LOADED = "Список событий загружен успешно",
    }
}

-- =============================================
-- CURRENT LANGUAGE
-- =============================================
CurrentLang = "ru"  -- "ru" or "en"

-- =============================================
-- Translation function
-- =============================================
function T(key)
    local lang = Lang[CurrentLang]
    return lang[key] or ("<missing:" .. key .. ">")
end
