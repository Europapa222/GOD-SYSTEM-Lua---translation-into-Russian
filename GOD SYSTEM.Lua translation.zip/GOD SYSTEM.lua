---- /godmode

-- Load language system first
require(fs.get_dir_script() .. 'GOD SYSTEM\\language.lua')

-- Creating main page
main_page = ui.new_page(T("MAIN_TITLE"), Icons.PORTAL)

-- Loading pages
require(fs.get_dir_script()..'GOD SYSTEM\\pages\\office.lua')
require(fs.get_dir_script()..'GOD SYSTEM\\pages\\businesses.lua')
require(fs.get_dir_script()..'GOD SYSTEM\\pages\\spawner.lua')
require(fs.get_dir_script()..'GOD SYSTEM\\pages\\misc.lua')

-- Loading events
require(fs.get_dir_script()..'GOD SYSTEM\\events.lua')

-- Popup ASCII
print('                                                                              ')
print('             **             **            **        **                        ')
print('            **          **     **        **        **                         ')
print('           **          **      **       ** **     **                          ')
print('          **          **               **   **   **                           ')
print('         **           **  ******      **     ** **                            ')
print('        *******       **    **       **        **   ' .. T("MADE_BY") .. '   ')
print('       *******          **          **        **   ' .. T("MAIN_TITLE") .. ' ')
print('                                                                              ')

-- UI popup
ui.popup(T("MAIN_TITLE"), T("LOADED_SUCCESS"), Icons.PORTAL, PopupType.BOX)
